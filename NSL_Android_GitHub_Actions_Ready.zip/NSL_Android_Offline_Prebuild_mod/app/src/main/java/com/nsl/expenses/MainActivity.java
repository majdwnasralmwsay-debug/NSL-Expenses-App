package com.nsl.expenses;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.util.Base64;
import android.view.WindowManager;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private WebView web;
    private WebView pdfWebView;
    private File pendingPdfFile;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setBlockNetworkLoads(true);
        s.setBlockNetworkImage(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidBridge(), "NSLAndroid");
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        web.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void shareText(String text, String title) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                i.putExtra(Intent.EXTRA_TITLE, title);
                startActivity(Intent.createChooser(i, title));
            });
        }

        /**
         * Receives only the rendered report HTML from the trusted local WebView.
         * Android creates the actual PDF and shares it through FileProvider.
         */
        @JavascriptInterface
        public void sharePdf(String reportHtml, String title) {
            runOnUiThread(() -> generatePdfAndShare(reportHtml, title));
        }

        @JavascriptInterface
        public void shareFile(String base64, String fileName, String mimeType, String title) {
            runOnUiThread(() -> {
                try {
                    if (base64 == null || base64.trim().isEmpty()) {
                        showWebAlert("الملف فارغ.");
                        return;
                    }
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    File dir = new File(getCacheDir(), "shared_files");
                    if (!dir.exists() && !dir.mkdirs()) throw new Exception("تعذر إنشاء مجلد المشاركة.");
                    String safeName = (fileName == null || fileName.trim().isEmpty()) ? "NSL_File" : fileName.replaceAll("[^A-Za-z0-9._-]", "_");
                    File file = new File(dir, safeName);
                    java.io.FileOutputStream out = new java.io.FileOutputStream(file);
                    out.write(data); out.flush(); out.close();
                    Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", file);
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
                    i.putExtra(Intent.EXTRA_STREAM, uri);
                    i.putExtra(Intent.EXTRA_TITLE, title == null ? safeName : title);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(i, title == null ? "مشاركة الملف" : title));
                } catch (Exception e) {
                    e.printStackTrace();
                    showWebAlert("تعذر تجهيز الملف للمشاركة.");
                }
            });
        }

        @JavascriptInterface
        public void openFile(Uri uri) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(uri);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(i, "فتح الملف"));
            });
        }
    }

    private void generatePdfAndShare(String reportHtml, String title) {
        if (reportHtml == null || reportHtml.trim().isEmpty()) {
            showWebAlert("لا يوجد تقرير جاهز لإنشاء ملف PDF.");
            return;
        }

        try {
            File dir = new File(getCacheDir(), "shared_pdfs");
            if (!dir.exists() && !dir.mkdirs()) {
                throw new Exception("تعذر إنشاء مجلد PDF المؤقت.");
            }

            String fileName = String.format(
                    Locale.US,
                    "Expenses_Report_%tY%tm%td_%tH%tM%tS.pdf",
                    System.currentTimeMillis(),
                    System.currentTimeMillis(),
                    System.currentTimeMillis(),
                    System.currentTimeMillis(),
                    System.currentTimeMillis()
            );
            pendingPdfFile = new File(dir, fileName);

            if (pdfWebView != null) {
                pdfWebView.stopLoading();
                pdfWebView.destroy();
            }

            pdfWebView = new WebView(this);
            WebSettings ps = pdfWebView.getSettings();
            ps.setJavaScriptEnabled(false);
            ps.setDomStorageEnabled(false);
            ps.setAllowFileAccess(false);
            ps.setAllowContentAccess(false);

            pdfWebView.setBackgroundColor(0xFFFFFFFF);
            pdfWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    createPdfFromWebView(view, title);
                }
            });

            String safeTitle = title == null || title.trim().isEmpty()
                    ? "تقرير المصروفات"
                    : title;

            String document = "<!DOCTYPE html><html lang=\"ar\" dir=\"rtl\"><head>"
                    + "<meta charset=\"UTF-8\">"
                    + "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">"
                    + "<title>" + escapeHtml(safeTitle) + "</title>"
                    + "<style>"
                    + "@page{size:A4;margin:12mm;}"
                    + "html,body{margin:0;padding:0;background:#fff;color:#111;"
                    + "font-family:Arial,'Noto Sans Arabic',sans-serif;direction:rtl;}"
                    + ".card{background:#fff;padding:12px;}"
                    + ".card-title{font-size:18px;font-weight:700;margin-bottom:14px;"
                    + "border-bottom:2px solid #10b981;padding-bottom:8px;}"
                    + ".table-responsive{width:100%;overflow:visible;}"
                    + "table{width:100%;border-collapse:collapse;font-size:12px;}"
                    + "th,td{padding:8px 6px;border:1px solid #d1d5db;text-align:right;}"
                    + "th{background:#f3f4f6;font-weight:700;}"
                    + "span{font-size:12px;}"
                    + "</style></head><body>"
                    + reportHtml
                    + "</body></html>";

            pdfWebView.loadDataWithBaseURL(
                    "file:///android_asset/",
                    document,
                    "text/html",
                    "UTF-8",
                    null
            );
        } catch (Exception e) {
            e.printStackTrace();
            showWebAlert("حدث خطأ أثناء تجهيز ملف PDF.");
            cleanupPdfWebView();
        }
    }

    private void createPdfFromWebView(WebView view, String title) {
        try {
            PrintDocumentAdapter adapter =
                    view.createPrintDocumentAdapter("NSL_Expenses_Report");

            PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution(
                            "nsl_pdf", "NSL PDF", 300, 300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build();

            adapter.onLayout(
                    null,
                    attributes,
                    new CancellationSignal(),
                    new PrintDocumentAdapter.LayoutResultCallback() {
                        @Override
                        public void onLayoutFinished(
                                android.print.PrintDocumentInfo info,
                                boolean changed) {
                            try {
                                android.os.ParcelFileDescriptor pfd =
                                        android.os.ParcelFileDescriptor.open(
                                                pendingPdfFile,
                                                android.os.ParcelFileDescriptor.MODE_CREATE
                                                        | android.os.ParcelFileDescriptor.MODE_TRUNCATE
                                                        | android.os.ParcelFileDescriptor.MODE_WRITE_ONLY
                                        );

                                adapter.onWrite(
                                        new PageRange[]{PageRange.ALL_PAGES},
                                        pfd,
                                        new CancellationSignal(),
                                        new PrintDocumentAdapter.WriteResultCallback() {
                                            @Override
                                            public void onWriteFinished(PageRange[] pages) {
                                                runOnUiThread(() ->
                                                        shareGeneratedPdf(pendingPdfFile, title));
                                            }

                                            @Override
                                            public void onWriteFailed(CharSequence error) {
                                                runOnUiThread(() -> {
                                                    showWebAlert("تعذر إنشاء ملف PDF.");
                                                    cleanupPdfWebView();
                                                });
                                            }
                                        }
                                );
                            } catch (Exception e) {
                                e.printStackTrace();
                                showWebAlert("تعذر حفظ ملف PDF.");
                                cleanupPdfWebView();
                            }
                        }

                        @Override
                        public void onLayoutFailed(CharSequence error) {
                            showWebAlert("تعذر تجهيز التقرير كملف PDF.");
                            cleanupPdfWebView();
                        }
                    },
                    new Bundle()
            );
        } catch (Exception e) {
            e.printStackTrace();
            showWebAlert("حدث خطأ أثناء تحويل التقرير إلى PDF.");
            cleanupPdfWebView();
        }
    }

    private void shareGeneratedPdf(File file, String title) {
        if (file == null || !file.exists() || file.length() == 0) {
            showWebAlert("لم يتم إنشاء ملف PDF صالح للمشاركة.");
            cleanupPdfWebView();
            return;
        }

        try {
            Uri uri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    file
            );

            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("application/pdf");
            shareIntent.putExtra(Intent.EXTRA_STREAM, uri);
            shareIntent.putExtra(
                    Intent.EXTRA_TEXT,
                    "تقرير المصروفات المالي المرفق كـ ملف PDF."
            );
            shareIntent.putExtra(
                    Intent.EXTRA_TITLE,
                    title == null ? "تقرير المصروفات" : title
            );
            shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            startActivity(Intent.createChooser(
                    shareIntent,
                    "مشاركة تقرير المصروفات"
            ));
        } catch (Exception e) {
            e.printStackTrace();
            showWebAlert("تعذر فتح قائمة مشاركة ملف PDF.");
        } finally {
            cleanupPdfWebView();
        }
    }

    private void cleanupPdfWebView() {
        if (pdfWebView != null) {
            pdfWebView.stopLoading();
            pdfWebView.destroy();
            pdfWebView = null;
        }
    }

    private void showWebAlert(String message) {
        if (web != null) {
            web.post(() -> web.evaluateJavascript(
                    "alert(" + javascriptString(message) + ");", null
            ));
        }
    }

    private static String javascriptString(String value) {
        if (value == null) return "\"\"";
        return "\"" + value
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n")
                .replace("<", "\\u003C")
                .replace(">", "\\u003E")
                .replace("&", "\\u0026") + "\"";
    }

    private static String escapeHtml(String value) {
        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        cleanupPdfWebView();
        if (web != null) {
            web.stopLoading();
            web.destroy();
        }
        super.onDestroy();
    }
}
